const verify_instance_accecibility = (username, instance)=>{
    
}