module.exports = {
    googleProjectID: 'reactpageagent-wicmma',
    dialogFlowSessionID:'react-bot-session',
    dialogFlowSessionLanguageCode:'en-US'
}