const get_bot_response =require('../services/database_services')
const welcome_waterfall = function (user_query) {
  let bot_response;
  switch (user_query) {

  }
  return bot_response;
};

module.exports.welcome_waterfall = welcome_waterfall;
