ufw disable
ufw status